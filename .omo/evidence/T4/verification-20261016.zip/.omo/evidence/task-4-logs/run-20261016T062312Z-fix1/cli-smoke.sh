#!/bin/sh
# T4 worker CLI smoke on an isolated pgvector container (run via with-test-db.sh).
# Happy: ingest -> lexical -> enrich READY. Failure: fake-timeout -> retry x2 -> FAILED,
# lexical still visible. DB time is advanced by rewriting next_attempt_at (no sleep).
set -u
W="uv run --package eventlens-worker eventlens-worker"
PY="uv run python"
sql() {
    $PY -c "import os,sys,psycopg; c=psycopg.connect(os.environ['EVENTLENS_RAG_DATABASE_URL']); r=c.execute(sys.argv[1]).fetchall(); c.commit(); print(r)" "$1"
}
step() {
    printf '\n$ %s\n' "$*"
    "$@"
    printf '[exit %s]\n' "$?"
}
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
# Second bundle: same shape, new article/media IDs and content (failure flow).
$PY - "$tmp/second.json" <<'EOF'
import json, sys
bundle = json.load(open("fixtures/article_bundle.v1.json"))
new_id = "6a0e8400-e29b-41d4-a716-446655440999"
bundle["article"]["article_id"] = new_id
bundle["article"]["content"] = "Cảng Hải Phòng tạm đóng cửa vì bão."
for item in bundle["media"]:
    item["article_id"] = new_id
json.dump(bundle, open(sys.argv[1], "w"), ensure_ascii=False)
EOF
echo "== HAPPY FLOW"
step $W ingest fixtures/article_bundle.v1.json
step $W ingest fixtures/article_bundle.v1.json
step sql "SELECT article_id FROM rag_current_lexical WHERE search_vector @@ plainto_tsquery('simple','công')"
step sql "SELECT status, attempt_count FROM rag_enrichment_jobs"
step $W enrich --max-jobs 5
step sql "SELECT status, attempt_count, claim_generation FROM rag_enrichment_jobs"
step sql "SELECT count(*) FROM rag_current_vectors"
step sql "SELECT count(*) FROM rag_enrichment_publications"
echo "== FAILURE FLOW (provider timeout)"
step $W ingest "$tmp/second.json"
for attempt in 1 2 3; do
    step $W enrich --provider fake-timeout --max-jobs 5
    step sql "SELECT status, attempt_count, failure_code, extract(epoch FROM next_attempt_at - updated_at)::int FROM rag_enrichment_jobs WHERE status <> 'READY'"
    step $W enrich --provider fake-timeout --max-jobs 5
    step sql "UPDATE rag_enrichment_jobs SET next_attempt_at = clock_timestamp() - interval '1 second' WHERE status = 'PENDING' RETURNING job_id"
done
step sql "SELECT article_id FROM rag_current_lexical WHERE search_vector @@ plainto_tsquery('simple','bão')"
step $W enrich --max-jobs 5
echo "== UNICODE HAPPY FLOW (review R4: casefold-expanding text before keyword)"
$PY - "$tmp/unicode.json" <<'EOF'
import json, sys
bundle = json.load(open("fixtures/article_bundle.v1.json"))
new_id = "7b0e8400-e29b-41d4-a716-446655440777"
bundle["article"]["article_id"] = new_id
bundle["article"]["content"] = "Straße harbor"
for item in bundle["media"]:
    item["article_id"] = new_id
json.dump(bundle, open(sys.argv[1], "w"), ensure_ascii=False)
EOF
step $W ingest "$tmp/unicode.json"
step $W enrich --max-jobs 5
step sql "SELECT span->>'excerpt', span->>'start_offset', span->>'end_offset' FROM rag_enrichment_versions v JOIN rag_enrichment_jobs j USING (job_id), jsonb_array_elements(v.metadata->'evidence_spans') span WHERE j.article_id = '7b0e8400-e29b-41d4-a716-446655440777'"
echo "== TYPED ERRORS"
step $W enrich --max-jobs 26
step $W ingest /dev/null
step env EVENTLENS_RAG_DATABASE_URL=postgresql://rag_test:x@127.0.0.1:1/rag_test $W enrich --max-jobs 1
exit 0
