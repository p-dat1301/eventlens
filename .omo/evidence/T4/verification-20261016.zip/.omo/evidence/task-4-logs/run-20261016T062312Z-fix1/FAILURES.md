# Failures in run-20261016T062312Z-fix1 (each kept, never overwritten)

| Attempt | Exit | Cause |
|---|---|---|
| `01-before-fix-regression.log` | 1 | Intended: the new review regression tests ran against the unfixed code on real pgvector (`eventlens-t4-fix1` dev container, DB `rag_test`): 10 failed / 2 passed. Failures reproduce R1 (2), R2 (1), R3 (2), R4 (5). The 2 passing are guard tests (`test_r2_duplicate_ingest_preserves_scheduled_retry`, sequential, and the `q̇ storm` R4 case, where casefold keeps the length). |
| first `cli-smoke` attempt (no log file) | 1 | Harness bug in the scratch log wrapper, not in product code: `sh` arithmetic read the log prefix `08` as octal (`value too great for base`). The wrapper stopped before running the command, so no `09-*.log` was created and nothing was recorded in `exit-codes.tsv`. Fixed by stripping leading zeros; rerun is `09-cli-smoke.log` (exit 0). |
| `05-gate-g1.log` | 2 | Not a failure: technical checks PASS; exit 2 is the gate's technical-only "acceptance OPEN" signal. |

No other attempt in this run failed.
