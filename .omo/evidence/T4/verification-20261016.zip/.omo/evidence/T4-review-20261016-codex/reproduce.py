"""Independent T4 failure probes, using an owned pgvector container only."""

from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
import json
import os
from pathlib import Path
import sys
from threading import Event, current_thread
from unittest.mock import patch
from uuid import uuid4

import psycopg
from psycopg import sql
from psycopg.conninfo import make_conninfo

sys.path.insert(0, str(Path.cwd() / "apps/rag/tests"))
from enrichment_support import CountingEmbeddings, document, identity_of

from eventlens_rag.adapters.fake_enricher import FakeArticleEnricher
from eventlens_rag.adapters.migrations import migrate
from eventlens_rag.adapters.postgres import PostgresRagStore
import eventlens_rag.adapters.postgres_enrichment as pg_enrichment
from eventlens_rag.adapters.postgres_enrichment import PostgresEnrichmentRepository
from eventlens_rag.adapters.staging import PostgresStaging
from eventlens_rag.adapters.telemetry import RecordingTelemetry
from eventlens_rag.application.enrichment import CancellationScope, EnrichmentSteps, bundled_retry_policy
from eventlens_rag.application.index import EnsureGeneration
from eventlens_rag.domain.embedding import EmbeddingIdentity
from eventlens_rag.domain.enrichment_lifecycle import CancelAck, FailureCode, OutcomeKind
from eventlens_rag.graph.enrichment import EnrichmentRunner

BASE = os.environ["EVENTLENS_RAG_DATABASE_URL"]
migrate(BASE)
FAKE = FakeArticleEnricher()
IDENTITY = identity_of(FAKE)
POLICY = bundled_retry_policy()


def log(name, **values):
    print(json.dumps({"probe": name, **values}, default=str, ensure_ascii=False), flush=True)


def database():
    schema = "review_" + uuid4().hex
    with psycopg.connect(BASE) as connection:
        connection.execute(sql.SQL("CREATE SCHEMA {}").format(sql.Identifier(schema)))
    url = make_conninfo(BASE, options="-c search_path=" + schema + ",public")
    migrate(url)
    return url


def rows(url, statement, params=()):
    with psycopg.connect(url) as connection:
        return connection.execute(statement, params).fetchall()


def runner(url, staging=None, embeddings=None):
    repository = PostgresEnrichmentRepository(url)
    steps = EnrichmentSteps(
        repository, FAKE,
        EnsureGeneration(staging or PostgresStaging(url), embeddings or CountingEmbeddings(), EmbeddingIdentity()),
        POLICY, lambda: datetime.now(UTC),
    )
    return EnrichmentRunner(steps, RecordingTelemetry()), repository


def stale_reconciliation():
    url = database()
    repository = PostgresEnrichmentRepository(url)
    old = document("Old Harbor Authority report")
    new = document("Corrected Harbor Authority report", article_id=old.article_id)
    PostgresRagStore(url).persist_article(old)
    paused, release = Event(), Event()
    original = pg_enrichment._enqueue

    def pause_old(connection, key):
        if key.content_hash == old.content_hash:
            paused.set()
            assert release.wait(20)
        return original(connection, key)

    with patch.object(pg_enrichment, "_enqueue", pause_old), ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(repository.enqueue_missing, IDENTITY, 25)
        assert paused.wait(20)
        try:
            receipt = repository.ingest(new, IDENTITY.key_for(new.article_id, new.content_hash))
            assert rows(url, "SELECT status FROM rag_enrichment_jobs WHERE job_id = %s", (receipt.job_id,)) == [("PENDING",)]
        finally:
            release.set()
        assert future.result(timeout=20) == 1
    assert repository.claim_next(IDENTITY, POLICY) is None
    assert repository.enqueue_missing(IDENTITY, 25) == 0
    states = rows(url, "SELECT content_hash, status FROM rag_enrichment_jobs ORDER BY created_at")
    assert len(states) == 2 and all(state == "STALE" for _, state in states)
    assert rows(url, "SELECT content_hash FROM rag_current_lexical") == [(new.content_hash,)]
    log("R1a_REPRODUCED_current_revision_stranded", states=states, next_claim=None, reconciled_again=0)


def reset_retry_budget():
    url = database()
    repository = PostgresEnrichmentRepository(url)
    article = document("Harbor Authority retry race")
    PostgresRagStore(url).persist_article(article)
    paused, release = Event(), Event()
    original = pg_enrichment.enqueue_revision_job

    def pause_after_prior(connection, key):
        if current_thread().name.startswith("review-reconcile"):
            paused.set()
            assert release.wait(20)
        return original(connection, key)

    with patch.object(pg_enrichment, "enqueue_revision_job", pause_after_prior), ThreadPoolExecutor(max_workers=1, thread_name_prefix="review-reconcile") as pool:
        future = pool.submit(repository.enqueue_missing, IDENTITY, 25)
        assert paused.wait(20)
        try:
            receipt = repository.ingest(article, IDENTITY.key_for(article.article_id, article.content_hash))
            claim = repository.claim_next(IDENTITY, POLICY)
            assert claim is not None and claim.attempt == 1
            assert repository.schedule_retry(claim, FailureCode.PROVIDER_TIMEOUT, 30)
            before = rows(url, "SELECT attempt_count, failure_code, next_attempt_at > clock_timestamp() FROM rag_enrichment_jobs WHERE job_id = %s", (receipt.job_id,))[0]
        finally:
            release.set()
        future.result(timeout=20)
    after = rows(url, "SELECT attempt_count, failure_code, next_attempt_at > clock_timestamp() FROM rag_enrichment_jobs WHERE job_id = %s", (receipt.job_id,))[0]
    assert before == (1, "provider_timeout", True)
    assert after == (0, None, False)
    log("R1b_REPRODUCED_retry_budget_reset", before=before, after=after)


def cancellation_during_stage():
    url = database()
    scope = CancellationScope()
    reached, release = Event(), Event()
    inner = PostgresStaging(url)
    writes_after_cancel = []

    class PausedStaging:
        def find_complete(self, article, identity):
            found = inner.find_complete(article, identity)
            reached.set()
            assert release.wait(20)
            return found

        def stage(self, request):
            writes_after_cancel.append(scope.stopped)
            return inner.stage(request)

    embeddings = CountingEmbeddings()
    worker, repository = runner(url, PausedStaging(), embeddings)
    article = document("Harbor Authority cancellation race")
    repository.ingest(article, IDENTITY.key_for(article.article_id, article.content_hash))
    with ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(worker.run, 1, scope)
        assert reached.wait(20)
        try:
            ack = scope.cancel()
            assert ack is CancelAck.ACKNOWLEDGED
        finally:
            release.set()
        report = future.result(timeout=20)
    assert report.outcomes[0].kind is OutcomeKind.CANCELLED
    assert writes_after_cancel == [True]
    assert rows(url, "SELECT count(*) FROM rag_index_generations") == [(1,)]
    assert rows(url, "SELECT count(*) FROM rag_chunks") == [(1,)]
    assert rows(url, "SELECT count(*) FROM rag_enrichment_publications") == [(0,)]
    log("R2_REPRODUCED_DB_work_after_cancel_ack", acknowledgement=ack, stage_started_after_cancel=writes_after_cancel, embeddings_after_cancel=embeddings.calls, generations=1, chunks=1, publications=0)


def already_cancelled_run():
    url = database()
    worker, _ = runner(url)
    PostgresRagStore(url).persist_article(document("Harbor Authority already cancelled"))
    scope = CancellationScope()
    scope.cancel()
    report = worker.run(1, scope)
    assert report.cancelled and report.reconciled == 1
    assert rows(url, "SELECT count(*) FROM rag_enrichment_jobs") == [(1,)]
    log("R2_REPRODUCED_pre_cancelled_run_enqueues", reconciled=report.reconciled, processed=len(report.outcomes))


def unicode_offsets():
    url = database()
    worker, repository = runner(url)
    article = document("Straße harbor")
    repository.ingest(article, IDENTITY.key_for(article.article_id, article.content_hash))
    report = worker.run(1)
    outcome = report.outcomes[0]
    assert outcome.kind is OutcomeKind.FAILED
    assert outcome.failure_code is FailureCode.UNGROUNDED_EVIDENCE
    log("R3_REPRODUCED_valid_unicode_article_fails", content=article.normalized_content, content_length=len(article.normalized_content), folded_length=len(article.normalized_content.casefold()), outcome=outcome.kind, failure=outcome.failure_code)


for probe in (stale_reconciliation, reset_retry_budget, cancellation_during_stage, already_cancelled_run, unicode_offsets):
    probe()
print("All five failure probes reproduced on real PostgreSQL/pgvector; this is not an implementation PASS.", flush=True)
