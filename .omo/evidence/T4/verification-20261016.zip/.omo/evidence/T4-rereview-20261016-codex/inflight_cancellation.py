"""Independent check: an in-flight embedding may finish, no next call or stage."""

from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
import json
import os
from pathlib import Path
import sys
from threading import Event

import psycopg

sys.path.insert(0, str(Path.cwd() / "apps/rag/tests"))
from enrichment_support import document, identity_of

from eventlens_rag.adapters.fake_embeddings import FakeEmbeddings
from eventlens_rag.adapters.fake_enricher import FakeArticleEnricher
from eventlens_rag.adapters.migrations import migrate
from eventlens_rag.adapters.postgres_enrichment import PostgresEnrichmentRepository
from eventlens_rag.adapters.staging import PostgresStaging
from eventlens_rag.adapters.telemetry import RecordingTelemetry
from eventlens_rag.application.enrichment import CancellationScope, EnrichmentSteps, bundled_retry_policy
from eventlens_rag.application.index import EnsureGeneration
from eventlens_rag.domain.chunking import chunk_document
from eventlens_rag.domain.embedding import EmbeddingIdentity
from eventlens_rag.domain.enrichment_lifecycle import CancelAck, OutcomeKind
from eventlens_rag.graph.enrichment import EnrichmentRunner

url = os.environ["EVENTLENS_RAG_DATABASE_URL"]
migrate(url)
scope = CancellationScope()
entered, release = Event(), Event()
calls = []
inner = FakeEmbeddings()


class PausedEmbedding:
    def embed(self, text):
        calls.append({"started_after_cancel": scope.stopped, "length": len(text)})
        entered.set()
        assert release.wait(20)
        return inner.embed(text)


enricher = FakeArticleEnricher()
repository = PostgresEnrichmentRepository(url)
article = document("Harbor Authority " + "Long report paragraph. " * 160)
assert len(chunk_document(article)) > 1
identity = identity_of(enricher)
repository.ingest(article, identity.key_for(article.article_id, article.content_hash))
steps = EnrichmentSteps(
    repository, enricher,
    EnsureGeneration(PostgresStaging(url), PausedEmbedding(), EmbeddingIdentity()),
    bundled_retry_policy(), lambda: datetime.now(UTC),
)
runner = EnrichmentRunner(steps, RecordingTelemetry())
with ThreadPoolExecutor(max_workers=1) as pool:
    future = pool.submit(runner.run, 1, scope)
    assert entered.wait(20)
    try:
        ack = scope.cancel()
        assert ack is CancelAck.ACKNOWLEDGED
    finally:
        release.set()
    report = future.result(timeout=20)
assert len(calls) == 1
assert calls[0]["started_after_cancel"] is False
assert [outcome.kind for outcome in report.outcomes] == [OutcomeKind.CANCELLED]
with psycopg.connect(url) as connection:
    counts = {table: connection.execute("SELECT count(*) FROM " + table).fetchone()[0]
              for table in ("rag_index_generations", "rag_chunks", "rag_enrichment_publications")}
assert all(value == 0 for value in counts.values())
print(json.dumps({"result": "PASS", "chunks_available": len(chunk_document(article)),
                  "embedding_calls": calls, "cancel_ack": ack, "rows": counts}, default=str), flush=True)
