#!/bin/sh
# Isolated verification of Makefile DB targets: separate Compose project, tmpfs,
# port 55432, legacy DDL copy loaded into that project's own `eventlens` DB.
set -u
E=.omo/evidence/G1/selfcheck-20261016
C="docker compose -p eventlens-g1-verify -f compose.yaml -f $E/compose-verify.override.yaml"
U=postgresql://eventlens:eventlens-local@127.0.0.1:55432
PG=eventlens-g1-verify-postgres-1
run() { label=$1; shift; "$@" >"$E/$label.log" 2>&1; c=$?; printf '%s\t%s\t%s\n' "$label" "$c" "$*" >>"$E/exit-codes.tsv"; echo "$label exit=$c | $(tail -n 1 "$E/$label.log")"; }
ddl() { docker exec $PG pg_dump -U eventlens -d eventlens --schema-only --no-owner --no-privileges | grep -v '^\\.*restrict' | shasum -a 256; }
run verify-infra-up $C --profile infra up -d --wait postgres
docker exec -i $PG psql -X -q -v ON_ERROR_STOP=1 -U eventlens -d eventlens <"$E/legacy-eventlens-schema.sql" >"$E/verify-legacy-load.log" 2>&1; echo "legacy load exit=$?"
ddl >"$E/verify-legacy-ddl-before.sha"
run verify-legacy-migrate make rag-migrate RAG_DATABASE_URL=$U/eventlens
ddl >"$E/verify-legacy-ddl-after.sha"
cmp "$E/verify-legacy-ddl-before.sha" "$E/verify-legacy-ddl-after.sha" && echo "legacy DDL unchanged: $(cat "$E/verify-legacy-ddl-after.sha")"
run verify-db-create make rag-db-create "COMPOSE=$C"
run verify-db-create-again make rag-db-create "COMPOSE=$C"
run verify-migrate make rag-migrate RAG_DATABASE_URL=$U/eventlens_rag
run verify-migrate-again make rag-migrate RAG_DATABASE_URL=$U/eventlens_rag
run verify-load-fixtures make rag-load-fixtures RAG_DATABASE_URL=$U/eventlens_rag
run verify-rebuild make rag-rebuild RAG_DATABASE_URL=$U/eventlens_rag
run verify-rebuild-again make rag-rebuild RAG_DATABASE_URL=$U/eventlens_rag
docker exec $PG psql -X -At -U eventlens -d eventlens_rag \
  -c "SELECT 'ledger='||count(*) FROM rag_schema_migrations" \
  -c "SELECT 'lexical='||count(*) FROM rag_current_lexical" \
  -c "SELECT 'vectors='||count(*) FROM rag_current_vectors" \
  -c "SELECT 'generations='||count(*) FROM rag_index_generations" \
  -c "SELECT 'harbor='||string_agg(article_id::text, ',' ORDER BY article_id) FROM rag_current_lexical WHERE search_vector @@ plainto_tsquery('simple','harbor')" \
  >"$E/verify-dedicated-db-state.txt" 2>&1
cat "$E/verify-dedicated-db-state.txt"
run verify-infra-down $C --profile infra down
docker volume ls --format '{{.Name}}' | grep -c '^eventlens-g1-verify' || true
