--
-- PostgreSQL database dump
--

\restrict deZe6fsFa1Nv4dzWbAmSf2KQiFMOAGKHkgXif1euhScJTj7Dnl1ubey2f2xWSPl

-- Dumped from database version 17.6 (Debian 17.6-1.pgdg12+1)
-- Dumped by pg_dump version 17.6 (Debian 17.6-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: prevent_article_document_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_article_document_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'article document revisions are immutable';
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: article_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_documents (
    article_id uuid NOT NULL,
    source_id uuid NOT NULL,
    title text NOT NULL,
    normalized_content text NOT NULL,
    canonical_url text NOT NULL,
    source_domain text NOT NULL,
    source_published_at timestamp with time zone,
    content_hash text NOT NULL,
    visibility text DEFAULT 'internal'::text NOT NULL,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, ((title || ' '::text) || normalized_content))) STORED,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: article_enrichment_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_enrichment_versions (
    article_id uuid NOT NULL,
    content_hash text NOT NULL,
    enrichment_version text NOT NULL,
    model_version text NOT NULL,
    prompt_version text NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rag_chunks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rag_chunks (
    chunk_id uuid NOT NULL,
    article_id uuid NOT NULL,
    content_hash text NOT NULL,
    chunk_index integer NOT NULL,
    chunk_fingerprint text NOT NULL,
    content text NOT NULL,
    embedding public.vector(1536)
);


--
-- Name: rag_document_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rag_document_versions (
    article_id uuid NOT NULL,
    content_hash text NOT NULL,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rag_index_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rag_index_metadata (
    index_name text NOT NULL,
    index_version text NOT NULL,
    embedding_dimensions integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT rag_index_metadata_embedding_dimensions_check CHECK ((embedding_dimensions = 1536))
);


--
-- Name: rag_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rag_jobs (
    job_id uuid NOT NULL,
    article_id uuid NOT NULL,
    content_hash text NOT NULL,
    idempotency_key text NOT NULL,
    status text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: article_documents article_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_documents
    ADD CONSTRAINT article_documents_pkey PRIMARY KEY (article_id, content_hash);


--
-- Name: article_enrichment_versions article_enrichment_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_enrichment_versions
    ADD CONSTRAINT article_enrichment_versions_pkey PRIMARY KEY (article_id, content_hash, enrichment_version);


--
-- Name: rag_chunks rag_chunks_article_id_content_hash_chunk_index_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_chunks
    ADD CONSTRAINT rag_chunks_article_id_content_hash_chunk_index_key UNIQUE (article_id, content_hash, chunk_index);


--
-- Name: rag_chunks rag_chunks_chunk_fingerprint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_chunks
    ADD CONSTRAINT rag_chunks_chunk_fingerprint_key UNIQUE (chunk_fingerprint);


--
-- Name: rag_chunks rag_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_chunks
    ADD CONSTRAINT rag_chunks_pkey PRIMARY KEY (chunk_id);


--
-- Name: rag_document_versions rag_document_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_document_versions
    ADD CONSTRAINT rag_document_versions_pkey PRIMARY KEY (article_id, content_hash);


--
-- Name: rag_index_metadata rag_index_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_index_metadata
    ADD CONSTRAINT rag_index_metadata_pkey PRIMARY KEY (index_name);


--
-- Name: rag_jobs rag_jobs_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_jobs
    ADD CONSTRAINT rag_jobs_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: rag_jobs rag_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_jobs
    ADD CONSTRAINT rag_jobs_pkey PRIMARY KEY (job_id);


--
-- Name: article_documents_canonical_url_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_documents_canonical_url_idx ON public.article_documents USING btree (canonical_url);


--
-- Name: article_documents_fts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_documents_fts_idx ON public.article_documents USING gin (search_vector);


--
-- Name: rag_chunks_embedding_hnsw_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rag_chunks_embedding_hnsw_idx ON public.rag_chunks USING hnsw (embedding public.vector_cosine_ops);


--
-- Name: rag_jobs_article_revision_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rag_jobs_article_revision_idx ON public.rag_jobs USING btree (article_id, content_hash);


--
-- Name: article_documents article_documents_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER article_documents_immutable BEFORE DELETE OR UPDATE ON public.article_documents FOR EACH ROW EXECUTE FUNCTION public.prevent_article_document_mutation();


--
-- Name: article_enrichment_versions article_enrichment_versions_article_id_content_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_enrichment_versions
    ADD CONSTRAINT article_enrichment_versions_article_id_content_hash_fkey FOREIGN KEY (article_id, content_hash) REFERENCES public.article_documents(article_id, content_hash);


--
-- Name: rag_chunks rag_chunks_article_id_content_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_chunks
    ADD CONSTRAINT rag_chunks_article_id_content_hash_fkey FOREIGN KEY (article_id, content_hash) REFERENCES public.article_documents(article_id, content_hash);


--
-- Name: rag_document_versions rag_document_versions_article_id_content_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_document_versions
    ADD CONSTRAINT rag_document_versions_article_id_content_hash_fkey FOREIGN KEY (article_id, content_hash) REFERENCES public.article_documents(article_id, content_hash);


--
-- Name: rag_jobs rag_jobs_article_id_content_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_jobs
    ADD CONSTRAINT rag_jobs_article_id_content_hash_fkey FOREIGN KEY (article_id, content_hash) REFERENCES public.article_documents(article_id, content_hash);


--
-- PostgreSQL database dump complete
--

\unrestrict deZe6fsFa1Nv4dzWbAmSf2KQiFMOAGKHkgXif1euhScJTj7Dnl1ubey2f2xWSPl

