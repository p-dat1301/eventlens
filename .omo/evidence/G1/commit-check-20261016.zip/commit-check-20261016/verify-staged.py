from pathlib import Path
import json
import os
import subprocess
import tempfile

repo = Path.cwd()
evidence = repo / ".omo/evidence/G1/commit-check-20261016"
evidence.mkdir(parents=True, exist_ok=True)
env = {key: value for key, value in os.environ.items()
       if key not in {"VIRTUAL_ENV", "PYTHONPATH", "EVENTLENS_RAG_DATABASE_URL", "G1_EVIDENCE_DIR"}}
results = []


def run(label, command, cwd, expected=0):
    print("Running " + label, flush=True)
    with (evidence / (label + ".log")).open("w") as log:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=log,
                                stderr=subprocess.STDOUT, check=False)
    results.append({"label": label, "command": command,
                    "exit": result.returncode, "expected": expected})
    (evidence / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(label + " exit=" + str(result.returncode), flush=True)
    if result.returncode != expected:
        print((evidence / (label + ".log")).read_text()[-10000:], flush=True)
        raise SystemExit(1)


tree = subprocess.check_output(["rtk", "proxy", "git", "write-tree"], text=True).strip()
(evidence / "staged-tree.txt").write_text(tree + "\n")
with tempfile.TemporaryDirectory(prefix="eventlens-g1-staged-", dir="/private/tmp") as directory:
    snapshot = Path(directory)
    run("checkout-index", ["rtk", "proxy", "git", "checkout-index", "--all", "--prefix=" + directory + "/"], repo)
    run("snapshot-git-init", ["rtk", "proxy", "git", "init", "-q"], snapshot)
    run("sync-python", ["rtk", "proxy", "uv", "sync", "--frozen", "--all-packages", "--group", "dev"], snapshot)
    run("sync-web", ["rtk", "proxy", "bun", "install", "--frozen-lockfile"], snapshot / "apps/web")
    run("make-check", ["rtk", "proxy", "make", "check"], snapshot)
    run("gate-g1", ["rtk", "proxy", "make", "gate-g1"], snapshot, expected=2)
    gate_files = sorted((snapshot / ".omo/evidence/G1").glob("run-*/technical-status"), key=lambda path: path.parent.name)
    technical = [path for path in gate_files if path.parent.name not in {"run-20261016T044334Z-44Ofkn", "run-20261016T045957Z-cBy0v8"}]
    assert len(technical) == 1, technical
    assert technical[0].read_text().strip() == "PASS"
    gate_dir = technical[0].parent
    for name in ("exit-codes.tsv", "pytest-db.log", "technical-status", "gate-status"):
        (evidence / ("snapshot-gate-" + name)).write_bytes((gate_dir / name).read_bytes())
    print("PASS: staged snapshot checks, real DB suite, and gate technical status", flush=True)

assert subprocess.check_output(["rtk", "proxy", "git", "write-tree"], text=True).strip() == tree
print("Staged index unchanged: " + tree, flush=True)
