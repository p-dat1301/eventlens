"""Independent defect probes; no implementation file is modified.
Run under apps/rag/with-test-db.sh with the eventlens-rag package environment.
Assertions document defects present in the reviewed snapshot, not acceptance tests.
"""
from pathlib import Path
import os, sys, json
from contextlib import contextmanager
from dataclasses import replace
from threading import Event, Thread
from unittest.mock import patch
from uuid import uuid4

sys.path.insert(0, str(Path.cwd() / "apps/rag/tests"))
import psycopg
from psycopg import sql
from psycopg.conninfo import make_conninfo
from retrieval_support import article, service, briefing, control, CALLER, MutableAccess
from eventlens_rag.adapters.migrations import migrate
from eventlens_rag.adapters.postgres import PostgresRagStore
from eventlens_rag.adapters.postgres_retrieval import PostgresRetrievalStore
from eventlens_rag.adapters.scripted_reranker import ScriptedReranker
from eventlens_rag.application.retrieve import RetrievalOptions
from eventlens_rag.ports.reranker import RerankOutput
# ADAPTED by implementer (2026-10-18): v2 removed Python `query_terms`
# (query lexemes now come from PostgreSQL). Import shim only; used solely in a log
# line. No assertion of this probe was changed.
def query_terms(text, policy):  # noqa: ARG001
    return ("<removed in retrieval-policy.v2: lexemes computed by PostgreSQL>",)
from eventlens_rag.domain import fusion

LEXICAL = RetrievalOptions(vector_enabled=False)

@contextmanager
def database():
    base = os.environ["EVENTLENS_RAG_DATABASE_URL"]
    name = "t5_review_" + uuid4().hex
    with psycopg.connect(base, autocommit=True) as c:
        c.execute(sql.SQL("CREATE SCHEMA {}").format(sql.Identifier(name)))
    url = make_conninfo(base, options=f"-c search_path={name},public")
    try:
        migrate(url)
        yield url
    finally:
        with psycopg.connect(base, autocommit=True) as c:
            c.execute(sql.SQL("DROP SCHEMA {} CASCADE").format(sql.Identifier(name)))


def log(name, **details):
    print(json.dumps({"probe": name, **details}, ensure_ascii=False), flush=True)


def revoked_during_final_fetch():
    with database() as url:
        doc = article("Harbor cranes resumed service.")
        PostgresRagStore(url).persist_article(doc)
        access = MutableAccess()
        entered, release = Event(), Event()
        outcome = {}
        original = PostgresRetrievalStore.current_articles
        def blocked(store, ids):
            states = original(store, ids)  # real PG batch fetch
            entered.set()
            assert release.wait(10)
            return states
        def retrieve():
            try:
                outcome["result"] = service(PostgresRetrievalStore(url), access=access).execute(
                    briefing("harbor"), CALLER, control(), LEXICAL)
            except BaseException as error:
                outcome["error"] = error
        with patch.object(PostgresRetrievalStore, "current_articles", blocked):
            worker = Thread(target=retrieve)
            worker.start()
            assert entered.wait(10)
            access.revoked = True  # revocation completes while final fetch is in-flight
            release.set()
            worker.join(10)
            assert not worker.is_alive()
        result = outcome.get("result")
        assert result is not None, repr(outcome.get("error"))
        assert result.articles and access.revoked
        log("access_revoked_during_final_fetch", access_revoked=access.revoked,
            access_checks=access.checks, returned_articles=len(result.articles),
            actual=result.status.value, expected="retrieval_access_denied")


def malformed_rerank_shape():
    with database() as url:
        PostgresRagStore(url).persist_article(article("Harbor cranes resumed service."))
        def malformed(request):
            return RerankOutput(scores=((request.candidates[0].candidate_id, 1.0, 2.0),))
        error = None
        try:
            service(PostgresRetrievalStore(url), reranker=ScriptedReranker(malformed)).execute(
                briefing("harbor"), CALLER, control(), LEXICAL)
        except BaseException as caught:
            error = caught
        assert isinstance(error, ValueError), repr(error)
        log("malformed_rerank_shape", actual=type(error).__name__, message=str(error),
            expected="evidence with rerank_status=degraded and invalid_output")


def unicode_lexical_prefilter():
    with database() as url:
        doc = article("Straße reopened today.", title="Transport notice")
        PostgresRagStore(url).persist_article(doc)
        with psycopg.connect(url) as c:
            direct = c.execute("SELECT count(*) FROM rag_current_lexical WHERE search_vector @@ plainto_tsquery('simple', %s)", ("Straße",)).fetchone()[0]
        runner = service(PostgresRetrievalStore(url))
        result = runner.execute(briefing("Straße"), CALLER, control(), LEXICAL)
        assert direct == 1 and not result.articles
        log("unicode_lexical_prefilter", query="Straße", terms=query_terms("Straße", runner.policy.tokenizer),
            direct_postgres_matches=direct, returned_articles=len(result.articles),
            actual=result.empty_reason.value, expected="one literal-word lexical match")


def unbounded_lexical_chunk_pool():
    with database() as url:
        doc = article("harbor reports continued. " * 12000, title="Harbor")
        PostgresRagStore(url).persist_article(doc)
        observed = []
        original = fusion._assign_ranks
        def record(scored, branch, depth, per_article):
            rows = list(scored)
            observed.append(len(rows))
            return original(rows, branch, depth, per_article)
        with patch.object(fusion, "_assign_ranks", record):
            result = service(PostgresRetrievalStore(url)).execute(
                briefing("harbor"), CALLER, control(), LEXICAL)
        assert observed[0] > 50 and len(result.articles) == 1
        log("unbounded_lexical_chunk_pool", content_codepoints=len(doc.normalized_content),
            intermediate_scored_chunks=observed[0], branch_depth=50,
            returned_spans=len(result.articles[0].spans),
            expected="explicit bounded intermediate chunk policy before full materialization/sort")


if __name__ == "__main__":
    revoked_during_final_fetch()
    malformed_rerank_shape()
    unicode_lexical_prefilter()
    unbounded_lexical_chunk_pool()
    print("All four independent defect probes reproduced.", flush=True)
