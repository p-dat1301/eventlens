"""Independent v2 checks: original defects fixed, plus adaptive regression probes.
Assertions on new defects document the reviewed source, not acceptance PASS.
Run against an owned database with apps/rag/with-test-db.sh.
"""
from pathlib import Path
import os,sys,json
from contextlib import contextmanager
from dataclasses import replace
from threading import Event,Thread
from unittest.mock import patch
from uuid import UUID,uuid4
sys.path.insert(0,str(Path.cwd()/"apps/rag/tests"))
import psycopg
from psycopg import sql
from psycopg.conninfo import make_conninfo
from retrieval_support import article,service,briefing,control,CALLER,MutableAccess
from eventlens_rag.adapters.migrations import migrate
from eventlens_rag.adapters.postgres import PostgresRagStore
from eventlens_rag.adapters.postgres_retrieval import PostgresRetrievalStore
from eventlens_rag.adapters.scripted_reranker import ScriptedReranker
from eventlens_rag.application.retrieve import RetrievalOptions
from eventlens_rag.ports.reranker import RerankOutput
from eventlens_rag.domain.retrieval import LexicalLimits,ChunkRef,RetrievalAccessDeniedError
from eventlens_rag.domain.chunking import chunk_document
from eventlens_rag.domain.fusion import rank_lexical
LEXICAL=RetrievalOptions(vector_enabled=False)

@contextmanager
def database():
 base=os.environ["EVENTLENS_RAG_DATABASE_URL"];name="t5_rereview_"+uuid4().hex
 with psycopg.connect(base,autocommit=True) as c:c.execute(sql.SQL("CREATE SCHEMA {}").format(sql.Identifier(name)))
 url=make_conninfo(base,options=f"-c search_path={name},public")
 try:
  migrate(url);yield url
 finally:
  with psycopg.connect(base,autocommit=True) as c:c.execute(sql.SQL("DROP SCHEMA {} CASCADE").format(sql.Identifier(name)))
def log(name,**kw):print(json.dumps({"probe":name,**kw},ensure_ascii=False),flush=True)
def limits(runner):
 p=runner.policy
 return LexicalLimits(stopwords=p.tokenizer.stopwords,max_terms=p.tokenizer.max_query_terms,
   article_pool=p.lexical.article_pool,chunks_scanned_per_article=p.lexical.max_chunks_scanned_per_article,
   chunks_per_article=p.lexical.max_chunks_per_article,  # ADAPTED: chunk_pool kwarg removed from LexicalLimits after R6
  
   chunk_size=runner.chunking.size,chunk_overlap=runner.chunking.overlap)

def original_r1():
 with database() as url:
  PostgresRagStore(url).persist_article(article("Harbor cranes resumed service."))
  access=MutableAccess();entered,release=Event(),Event();outcome={}
  orig=PostgresRetrievalStore.current_articles
  def blocked(store,ids):
   states=orig(store,ids);entered.set();assert release.wait(10);return states
  def run():
   try:outcome["result"]=service(PostgresRetrievalStore(url),access=access).execute(briefing("harbor"),CALLER,control(),LEXICAL)
   except BaseException as e:outcome["error"]=e
  with patch.object(PostgresRetrievalStore,"current_articles",blocked):
   t=Thread(target=run);t.start();assert entered.wait(10);access.revoked=True;release.set();t.join(10);assert not t.is_alive()
  assert isinstance(outcome.get("error"),RetrievalAccessDeniedError),str(outcome)
  log("R1_original_final_fetch",result="PASS",error=outcome["error"].code)

def original_r2():
 with database() as url:
  PostgresRagStore(url).persist_article(article("Harbor cranes resumed service."))
  def malformed(req):return RerankOutput(scores=((req.candidates[0].candidate_id,1.,2.),))
  result=service(PostgresRetrievalStore(url),reranker=ScriptedReranker(malformed)).execute(briefing("harbor"),CALLER,control(),LEXICAL)
  assert result.rerank_status.value=="degraded" and result.rerank_degrade_reason.value=="invalid_output" and result.articles
  log("R2_original_malformed_shape",result="PASS",status=result.rerank_status.value,reason=result.rerank_degrade_reason.value)

def original_r3():
 with database() as url:
  doc=article("Straße reopened today.",title="Transport notice");PostgresRagStore(url).persist_article(doc)
  result=service(PostgresRetrievalStore(url)).execute(briefing("Straße"),CALLER,control(),LEXICAL)
  assert [a.article_id for a in result.articles]==[doc.article_id]
  log("R3_original_unicode",result="PASS",returned_articles=len(result.articles))

def original_r4():
 with database() as url:
  doc=article("harbor reports continued. "*12000,title="Harbor");PostgresRagStore(url).persist_article(doc)
  store=PostgresRetrievalStore(url);runner=service(store);page=store.lexical_chunks("harbor",__import__("eventlens_rag.ports.retrieval",fromlist=["RetrievalScope"]).RetrievalScope((),None,None,None),limits(runner))
  assert len(page.chunks)<=runner.policy.lexical.max_chunks_per_article and page.truncated_articles==1
  result=runner.execute(briefing("harbor"),CALLER,control(),LEXICAL)
  assert result.metrics.lexical_truncated_articles==1
  log("R4_original_long_article",result="PASS",content_codepoints=len(doc.normalized_content),returned_pool=len(page.chunks),scan_cap=runner.policy.lexical.max_chunks_scanned_per_article,truncated_articles=page.truncated_articles)

def empty_return_revocation():
 with database() as url:
  PostgresRagStore(url).persist_article(article("Harbor cranes resumed service."))
  access=MutableAccess();orig=PostgresRetrievalStore.metadata_eligibility
  def revoked_after(store,*args):
   found=orig(store,*args);access.revoked=True;return found
  with patch.object(PostgresRetrievalStore,"metadata_eligibility",revoked_after):
   result=service(PostgresRetrievalStore(url),access=access).execute(briefing("harbor",topic_filters=("transportation",)),CALLER,control(),LEXICAL)
  assert access.revoked and result.status.value=="empty"
  log("new_empty_return_after_access_revocation",actual=result.status.value,reason=result.empty_reason.value,access_checks=access.checks,leaked_scoped_count=result.coverage.scoped_articles,expected="retrieval_access_denied")

def sql_chunk_tie_selection():
 from eventlens_rag.ports.retrieval import RetrievalScope
 with database() as url:
  text=" ".join(f"token{i:05d}" for i in range(600))
  doc=article(text,title="Harbor",article_id=UUID(int=1));PostgresRagStore(url).persist_article(doc)
  store=PostgresRetrievalStore(url);runner=service(store);cfg=limits(runner);scope=RetrievalScope((),None,None,None)
  selected=store.lexical_chunks("harbor",scope,cfg)
  whole=store.lexical_chunks("harbor",scope,replace(cfg,chunks_per_article=40))
  actual=rank_lexical(selected,runner.clock(),runner.policy.lexical,runner.policy.freshness,runner.policy.chunker_version)
  expected=rank_lexical(whole,runner.clock(),runner.policy.lexical,runner.policy.freshness,runner.policy.chunker_version)
  got=[i.chunk.chunk_index for i in actual];want=[i.chunk.chunk_index for i in expected]
  assert got!=want,(got,want)
  log("new_sql_tie_selection",actual=got,expected_by_frozen_ties=want,scanned_chunks=len(whole.chunks),sql_kept=[c.chunk_index for c in selected.chunks],policy_ties=runner.policy.lexical.ties)

if __name__=="__main__":
 # ADAPTED: run each probe in isolation and report its own outcome, so one
 # failing assertion does not hide the others. Assertions are unchanged.
 import traceback
 failed = 0
 for probe in (original_r1, original_r2, original_r3, original_r4, empty_return_revocation, sql_chunk_tie_selection):
  try:
   probe()
   print(json.dumps({"probe_function": probe.__name__, "assertions": "held"}), flush=True)
  except AssertionError as error:
   failed += 1
   print(json.dumps({"probe_function": probe.__name__, "assertions": "FAILED", "detail": str(error)[:300]}), flush=True)
  except Exception as error:
   failed += 1
   print(json.dumps({"probe_function": probe.__name__, "error": type(error).__name__, "detail": str(error)[:300]}), flush=True)
 sys.exit(1 if failed else 0)
