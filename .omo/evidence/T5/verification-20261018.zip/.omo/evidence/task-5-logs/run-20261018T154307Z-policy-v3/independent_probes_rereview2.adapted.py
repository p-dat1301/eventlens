"""Independent checks for R5/R6 and the changed lexical intermediate bounds.
Use the isolated PostgreSQL harness. Does not modify runtime files or old probes.
"""
from pathlib import Path
import os,sys,json
from contextlib import contextmanager
from threading import Event,Thread
from unittest.mock import patch
from uuid import UUID,uuid4,uuid5
sys.path.insert(0,str(Path.cwd()/"apps/rag/tests"))
import psycopg
from psycopg import sql
from psycopg.conninfo import make_conninfo
from retrieval_support import article,service,briefing,control,CALLER,MutableAccess
from eventlens_rag.adapters.migrations import migrate
from eventlens_rag.adapters.postgres import PostgresRagStore
from eventlens_rag.adapters.postgres_retrieval import PostgresRetrievalStore,LEXICAL_SQL,CHUNK_TEXT_SQL
from eventlens_rag.application.retrieve import RetrievalOptions
from eventlens_rag.domain.retrieval import CHUNK_NAMESPACE,LexicalLimits,RetrievalAccessDeniedError
from eventlens_rag.domain.fusion import rank_lexical
from eventlens_rag.ports.retrieval import RetrievalScope

LEXICAL=RetrievalOptions(vector_enabled=False,rerank_enabled=False)

@contextmanager
def database():
 base=os.environ["EVENTLENS_RAG_DATABASE_URL"];name="t5_rereview2_"+uuid4().hex
 with psycopg.connect(base,autocommit=True) as c:c.execute(sql.SQL("CREATE SCHEMA {}").format(sql.Identifier(name)))
 url=make_conninfo(base,options=f"-c search_path={name},public")
 try:
  migrate(url);yield url
 finally:
  with psycopg.connect(base,autocommit=True) as c:c.execute(sql.SQL("DROP SCHEMA {} CASCADE").format(sql.Identifier(name)))

def log(name,**kw):print(json.dumps({"probe":name,**kw},ensure_ascii=False),flush=True)
def limits(r):
 p=r.policy
 return LexicalLimits(stopwords=p.tokenizer.stopwords,max_terms=p.tokenizer.max_query_terms,article_pool=p.lexical.article_pool,
  chunks_scanned_per_article=p.lexical.max_chunks_scanned_per_article,chunks_per_article=p.lexical.max_chunks_per_article,
  max_metadata_candidates=p.lexical.max_metadata_candidates,  # ADAPTED: new required v3 field
  chunk_size=r.chunking.size,chunk_overlap=r.chunking.overlap)

def revocation_empty():
 for kind in ("metadata","zero_hit"):
  with database() as url:
   store=PostgresRagStore(url);store.persist_article(article("Bakery bread baked today.",title="Bakery news"))
   access=MutableAccess();entered,release=Event(),Event();outcome={}
   method="metadata_eligibility" if kind=="metadata" else "lexical_chunks"
   orig=getattr(PostgresRetrievalStore,method)
   def paused(obj,*args):
    rows=orig(obj,*args);entered.set();assert release.wait(10);return rows
   def run():
    try:
     kwargs={"topic_filters":("transportation",)} if kind=="metadata" else {}
     outcome["result"]=service(PostgresRetrievalStore(url),access=access).execute(briefing("harbor",**kwargs),CALLER,control(),LEXICAL)
    except BaseException as e:outcome["error"]=e
   with patch.object(PostgresRetrievalStore,method,paused):
    t=Thread(target=run);t.start();assert entered.wait(10);access.revoked=True;release.set();t.join(10);assert not t.is_alive()
   assert isinstance(outcome.get("error"),RetrievalAccessDeniedError),str(outcome)
   assert "result" not in outcome
   log("R5_"+kind,result="PASS",code=outcome["error"].code)

def tie_order():
 with database() as url:
  doc=article(" ".join(f"token{i:05d}" for i in range(600)),title="Harbor",article_id=UUID(int=1))
  PostgresRagStore(url).persist_article(doc)
  runner=service(PostgresRetrievalStore(url));cfg=limits(runner);scope=RetrievalScope((),None,None,None)
  page=runner.store.lexical_chunks("harbor",scope,cfg)
  ranked=rank_lexical(page,runner.clock(),runner.policy.lexical,runner.policy.freshness,runner.policy.chunker_version)
  def cid(i):return str(uuid5(CHUNK_NAMESPACE,f"{doc.article_id}|{doc.content_hash}|{runner.chunking.version}|{i}"))
  # 600 * 11 - 1 = 6599 code points -> seven windows by T3 arithmetic.
  expected=sorted(range(7),key=cid)[:3]
  actual=[item.chunk.chunk_index for item in ranked]
  assert actual==expected,(actual,expected)
  result=runner.execute(briefing("harbor"),CALLER,control(),LEXICAL)
  assert [s.chunk_index for s in result.articles[0].spans]==expected
  log("R6_frozen_ties",result="PASS",expected=expected,actual=actual,metadata_rows=len(page.chunks))

def worst_case_rows():
 with database() as url:
  persisted=PostgresRagStore(url)
  # 51 equally ranked articles, each with 41 windows; query matches the title,
  # so all first 40 windows per selected article tie at the SQL boundary.
  for index in range(51):
   body=(f"body{index:02d}xxxxxxxx "*4000)[:41200]
   persisted.persist_article(article(body,title="Harbor",article_id=UUID(int=index+1)))
  store=PostgresRetrievalStore(url);runner=service(store);records=[];orig=PostgresRetrievalStore._fetch
  def record(obj,statement,params):
   rows=orig(obj,statement,params)
   if statement==LEXICAL_SQL:records.append(("metadata",len(rows)))
   elif statement==CHUNK_TEXT_SQL:records.append(("text",len(rows)))
   return rows
  with patch.object(PostgresRetrievalStore,"_fetch",record):
   result=runner.execute(briefing("harbor"),CALLER,control(),LEXICAL)
  metadata=[n for k,n in records if k=="metadata"]
  texts=[n for k,n in records if k=="text"]
  assert metadata==[2000],records
  assert texts==[50],records
  assert result.metrics.lexical_truncated_articles==50
  assert metadata[0]>runner.policy.lexical.chunk_pool
  log("R4_policy_pool_mismatch",policy=runner.policy.policy_id,declared_chunk_pool=runner.policy.lexical.chunk_pool,
   metadata_rows=metadata[0],text_rows=texts[0],metadata_bound=runner.policy.lexical.article_pool*runner.policy.lexical.max_chunks_scanned_per_article,
   query_articles=51,selected_articles=50,lexical_truncated_articles=result.metrics.lexical_truncated_articles,storage_statements=store.statements,
   conclusion="finite 2000-row metadata scan; original 150-row chunk-pool contract no longer enforced")

if __name__=="__main__":
 # ADAPTED: run each probe in isolation and report its own outcome; assertions unchanged.
 failed = 0
 for probe in (revocation_empty, tie_order, worst_case_rows):
  try:
   probe()
   print(json.dumps({"probe_function": probe.__name__, "assertions": "held"}), flush=True)
  except Exception as error:
   failed += 1
   tb = error.__traceback__
   while tb.tb_next is not None:
    tb = tb.tb_next
   print(json.dumps({"probe_function": probe.__name__, "error": type(error).__name__, "detail": str(error)[:300], "line": tb.tb_lineno}), flush=True)
 sys.exit(1 if failed else 0)
