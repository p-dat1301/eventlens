#!/bin/sh
# T5 evidence runner: one log per command, exit codes appended, never overwritten.
set -u
dir=$(dirname "$0")
step() {
    label=$1; shift
    printf '== %s: %s\n' "$label" "$*"
    "$@" >"$dir/$label.log" 2>&1
    code=$?
    printf '%s\t%s\t%s\n' "$label" "$code" "$*" >>"$dir/exit-codes.tsv"
    printf '== exit %s\n' "$code"
    tail -n 4 "$dir/$label.log"
}
case "${1:-all}" in
core)
    step make-check rtk proxy env -u VIRTUAL_ENV -u EVENTLENS_RAG_DATABASE_URL make check
    step make-rag-db-test rtk proxy env -u VIRTUAL_ENV -u EVENTLENS_RAG_DATABASE_URL make rag-db-test
    step targeted-pytest rtk proxy env -u VIRTUAL_ENV -u EVENTLENS_RAG_DATABASE_URL sh apps/rag/with-test-db.sh uv run --package eventlens-rag pytest apps/rag/tests/test_retrieval.py apps/rag/tests/test_evidence_context.py apps/rag/tests/test_review_fixes.py apps/rag/tests/test_t5_review_fixes.py -q -rs
    step git-diff-check rtk git diff --check
    ;;
smoke)
    step retrieval-smoke rtk proxy env -u VIRTUAL_ENV -u EVENTLENS_RAG_DATABASE_URL sh apps/rag/with-test-db.sh uv run --package eventlens-rag eventlens-rag retrieval-smoke --output "$PWD/$dir/retrieval-smoke.json"
    step vector-route-report rtk proxy env -u VIRTUAL_ENV -u EVENTLENS_RAG_DATABASE_URL sh apps/rag/with-test-db.sh uv run --package eventlens-rag eventlens-rag vector-route-report --output "$PWD/$dir/vector-routes" --articles 3000 --queries 20 --k 10
    ;;
smoke-only)
    step retrieval-smoke rtk proxy env -u VIRTUAL_ENV -u EVENTLENS_RAG_DATABASE_URL sh apps/rag/with-test-db.sh uv run --package eventlens-rag eventlens-rag retrieval-smoke --output "$PWD/$dir/retrieval-smoke.json"
    ;;
probes)
    step review-probes-after-fix rtk proxy env -u VIRTUAL_ENV -u EVENTLENS_RAG_DATABASE_URL sh apps/rag/with-test-db.sh uv run --package eventlens-rag python .omo/evidence/T5-review-20261018-codex/independent_probes.py
    ;;
gate)
    step make-gate-g1 rtk proxy env -u VIRTUAL_ENV -u EVENTLENS_RAG_DATABASE_URL make gate-g1
    ;;
esac
